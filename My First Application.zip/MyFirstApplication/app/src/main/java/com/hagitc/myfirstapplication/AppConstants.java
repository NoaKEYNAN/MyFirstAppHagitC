package com.hagitc.myfirstapplication;

public class AppConstants {

    public final static int ONE_PHONE = 1;
    public final static int TWO_PHONES = 2;

    public final static String GAME_CONFIG = "GameConfiguration";

    public final static String HOST = "host";

    public final static String OTHER = "other";


}
